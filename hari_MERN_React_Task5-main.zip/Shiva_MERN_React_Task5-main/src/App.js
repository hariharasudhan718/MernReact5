import React from 'react';
import logo from './logo.svg';
import './App.css'; 
import AgeCalculator from './Components/AgeCalculator';
function App() {
  return (
    <div className="App">
       <AgeCalculator></AgeCalculator>
    </div>
  );
}
export default App;
